from django.apps import AppConfig


class GuessConfig(AppConfig):
    name = 'guess'
